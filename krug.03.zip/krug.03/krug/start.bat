@echo off
chcp 65001 >nul
cd /d "%~dp0"
where node >nul 2>nul || (echo Сначала установите Node.js с https://nodejs.org, затем запустите этот файл снова. & pause & exit /b)
if not exist node_modules call npm install
node setup.js
pause
