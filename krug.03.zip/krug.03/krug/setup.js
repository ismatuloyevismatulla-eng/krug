'use strict';
// Первый запуск: спрашивает ключи, сохраняет в .env и запускает сайт.
const fs = require('fs'), path = require('path'), readline = require('readline');
const envPath = path.join(__dirname, '.env');
const rl = readline.createInterface({ input: process.stdin, output: process.stdout });
const ask = q => new Promise(r => rl.question(q, a => r(a.trim())));

(async () => {
  if (!fs.existsSync(envPath)) {
    console.log('\n=== Первая настройка сайта «Круг» ===\nВставляйте значения правой кнопкой мыши и нажимайте Enter.\n');
    let id = '';  while (!id.endsWith('.apps.googleusercontent.com')) id = await ask('1) Client ID (заканчивается на .apps.googleusercontent.com): ');
    let mail = ''; while (!/^[^\s@]+@gmail\.com$/i.test(mail)) mail = await ask('2) Ваш Gmail, с которого уходят коды: ');
    let pass = ''; while (pass.replace(/\s/g, '').length !== 16) pass = await ask('3) Пароль приложения (16 символов): ');
    const owner = (await ask(`4) Почта владельца сайта — получит админ-панель (Enter = ${mail}): `)) || mail;
    const site = (await ask('5) Название сайта (Enter = Круг): ')) || 'Круг';
    fs.writeFileSync(envPath, `GOOGLE_CLIENT_ID=${id}\nGMAIL_USER=${mail}\nGMAIL_APP_PASSWORD=${pass.replace(/\s/g, '')}\nOWNER_EMAIL=${owner}\nSITE_NAME=${site}\nPORT=8000\n`);
    console.log('\nГотово! Настройки сохранены. Чтобы ввести их заново, удалите файл .env\n');
  }
  rl.close();
  require('./server.js');
})();
