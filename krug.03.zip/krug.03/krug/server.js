'use strict';
require('dotenv').config();
const express = require('express'), crypto = require('crypto'), path = require('path'), fs = require('fs');
const nodemailer = require('nodemailer'), rateLimit = require('express-rate-limit');
const { OAuth2Client } = require('google-auth-library');
const { GOOGLE_CLIENT_ID, GMAIL_USER, GMAIL_APP_PASSWORD, PORT = 8000 } = process.env;
if (!GOOGLE_CLIENT_ID || !GMAIL_USER || !GMAIL_APP_PASSWORD) { console.error('Заполните GOOGLE_CLIENT_ID, GMAIL_USER и GMAIL_APP_PASSWORD'); process.exit(1); }

// Владелец сайта: только этот email получает роль owner (меняется через OWNER_EMAIL)
const OWNER = (process.env.OWNER_EMAIL || 'ismatuloyevismatulla@gmail.com').toLowerCase();
const SITE = process.env.SITE_NAME || 'Круг';
const googleClient = new OAuth2Client(GOOGLE_CLIENT_ID);
const mailer = nodemailer.createTransport({ service: 'gmail', auth: { user: GMAIL_USER, pass: GMAIL_APP_PASSWORD } });

/* ---------- Простая база в файле db.json (users, listings, secret) ---------- */
const DB_FILE = path.join(process.env.DATA_DIR || __dirname, 'db.json');
let db = { users: {}, listings: [], secret: crypto.randomBytes(32).toString('hex') };
try { db = { ...db, ...JSON.parse(fs.readFileSync(DB_FILE, 'utf8')) }; } catch {}
const save = () => fs.writeFileSync(DB_FILE, JSON.stringify(db));
save();

/* ---------- Сессии: подписанная httpOnly-cookie ---------- */
const mac = b => crypto.createHmac('sha256', db.secret).update(b).digest('base64url');
const sign = e => { const b = Buffer.from(e).toString('base64url'); return b + '.' + mac(b); };
const unsign = t => { const [b, m] = String(t || '').split('.'); if (!b || !m) return null; const ok = mac(b); return m.length === ok.length && crypto.timingSafeEqual(Buffer.from(m), Buffer.from(ok)) ? Buffer.from(b, 'base64url').toString() : null; };
const cookies = req => Object.fromEntries((req.headers.cookie || '').split(';').map(c => c.trim().split('=')).filter(a => a[0]).map(([k, ...v]) => [k, v.join('=')]));
const pub = u => ({ email: u.email, name: u.name, picture: u.picture, role: u.role, applied: !!u.applied, banned: !!u.banned, joined: u.joined });

const app = express();
app.set('trust proxy', 1);
app.use(express.json({ limit: '3mb' }));
app.use((req, res, next) => { const e = unsign(cookies(req).sid); const u = e && db.users[e]; req.user = u && !u.banned ? u : null; next(); });
const need = (...roles) => (req, res, next) => req.user && roles.includes(req.user.role) ? next() : res.status(403).json({ error: 'forbidden' });
const isStaff = need('admin', 'owner'), canSell = need('seller', 'admin', 'owner');

app.get('/config.js', (req, res) => res.type('application/javascript').send('window.KRUG_CONFIG=' + JSON.stringify({ clientId: GOOGLE_CLIENT_ID, api: '/api', siteName: SITE }) + ';'));
app.use(express.static(path.join(__dirname, 'public')));
app.use('/api', rateLimit({ windowMs: 10 * 60 * 1000, max: 300, standardHeaders: true, legacyHeaders: false }));

/* ---------- Вход: Google → код на почту ---------- */
const codes = new Map(), hash = c => crypto.createHash('sha256').update(c).digest('hex');
app.post('/api/auth/google', async (req, res) => {
  try {
    const p = (await googleClient.verifyIdToken({ idToken: String(req.body.credential || ''), audience: GOOGLE_CLIENT_ID })).getPayload();
    if (!p.email || !p.email_verified) return res.status(400).json({ error: 'email_not_verified' });
    const email = p.email.toLowerCase(), prev = codes.get(email);
    if (prev && Date.now() - prev.sent < 30000) return res.status(429).json({ error: 'too_soon' });
    if (db.users[email]?.banned) return res.status(403).json({ error: 'banned' });
    const code = String(crypto.randomInt(0, 1000000)).padStart(6, '0');
    codes.set(email, { hash: hash(code), exp: Date.now() + 600000, attempts: 0, sent: Date.now(), name: p.name || email, picture: p.picture || '' });
    await mailer.sendMail({ from: `${SITE} <${GMAIL_USER}>`, to: email, subject: `Ваш код входа: ${code}`,
      text: `Код для сайта «${SITE}»: ${code}. Действует 10 минут.`,
      html: `<p>Код для сайта «${SITE}»:</p><p style="font-size:32px;font-weight:700;letter-spacing:6px">${code}</p><p>Действует 10 минут.</p>` });
    res.json({ ok: true });
  } catch (e) { console.error('auth/google:', e.message); res.status(400).json({ error: 'auth_failed' }); }
});
app.post('/api/auth/verify', (req, res) => {
  const email = String(req.body?.email || '').toLowerCase(), code = String(req.body?.code || ''), rec = codes.get(email);
  if (!rec || Date.now() > rec.exp) { codes.delete(email); return res.status(400).json({ error: 'expired' }); }
  if (++rec.attempts > 5) { codes.delete(email); return res.status(429).json({ error: 'too_many_attempts' }); }
  if (!/^\d{6}$/.test(code) || !crypto.timingSafeEqual(Buffer.from(hash(code)), Buffer.from(rec.hash))) return res.status(400).json({ error: 'wrong_code' });
  codes.delete(email);
  const u = db.users[email] ||= { email, role: 'user', joined: Date.now() };
  u.name = rec.name; u.picture = rec.picture;
  if (email === OWNER) u.role = 'owner';
  save();
  res.cookie('sid', sign(email), { httpOnly: true, sameSite: 'lax', secure: process.env.NODE_ENV === 'production', maxAge: 30 * 864e5 });
  res.json({ ok: true, user: pub(u) });
});

/* ---------- Аккаунт ---------- */
app.get('/api/me', (req, res) => res.json({ user: req.user ? pub(req.user) : null }));
app.post('/api/logout', (req, res) => { res.clearCookie('sid'); res.json({ ok: true }); });
app.post('/api/apply', need('user'), (req, res) => { req.user.applied = true; save(); res.json({ ok: true }); });
app.post('/api/account/delete', need('user', 'seller', 'admin'), (req, res) => {
  if (req.body?.confirm !== 2) return res.status(400).json({ error: 'need_two_confirmations' }); // два предупреждения пройдены
  db.listings = db.listings.filter(l => l.sellerEmail !== req.user.email);
  delete db.users[req.user.email]; save(); res.clearCookie('sid'); res.json({ ok: true });
});

/* ---------- Объявления ---------- */
const CATS = ['Одежда', 'Техника', 'Дом', 'Спорт', 'Книги'];
app.get('/api/listings', (req, res) => res.json({ listings: [...db.listings].sort((a, b) => b.t - a.t).map(({ sellerEmail, ...l }) => req.user ? { ...l, sellerEmail } : l) })); // контакты продавцов видны только вошедшим
app.post('/api/listings', canSell, (req, res) => {
  const { title, cat, price, desc, img } = req.body || {};
  if (String(title || '').trim().length < 3 || !CATS.includes(cat) || !(Number(price) > 0) || String(desc || '').trim().length < 10) return res.status(400).json({ error: 'invalid' });
  if (img && (!/^data:image\/jpeg;base64,/.test(img) || img.length > 600000)) return res.status(400).json({ error: 'bad_image' });
  const l = { id: crypto.randomUUID(), title: String(title).trim().slice(0, 60), cat, price: Number(price), desc: String(desc).trim().slice(0, 300), img: img || '', seller: req.user.name, sellerEmail: req.user.email, t: Date.now() };
  db.listings.push(l); save(); res.json({ ok: true, listing: l });
});
app.delete('/api/listings/:id', need('seller', 'admin', 'owner'), (req, res) => {
  const l = db.listings.find(x => x.id === req.params.id);
  if (!l) return res.status(404).json({ error: 'not_found' });
  if (l.sellerEmail !== req.user.email && !['admin', 'owner'].includes(req.user.role)) return res.status(403).json({ error: 'forbidden' });
  db.listings = db.listings.filter(x => x.id !== l.id); save(); res.json({ ok: true });
});

/* ---------- Админка (admin и owner; всё проверяется здесь, на сервере) ---------- */
app.get('/api/admin/data', isStaff, (req, res) => res.json({ users: Object.values(db.users).map(pub).sort((a, b) => b.joined - a.joined), listings: db.listings.map(({ img, ...l }) => l) }));
app.post('/api/admin/role', isStaff, (req, res) => {
  const t = db.users[String(req.body?.email || '').toLowerCase()], role = req.body?.role, me = req.user;
  if (!t || !['user', 'seller', 'admin'].includes(role)) return res.status(400).json({ error: 'invalid' });
  if (t.role === 'owner' || t.email === OWNER) return res.status(403).json({ error: 'owner_protected' });
  if ((role === 'admin' || t.role === 'admin') && me.role !== 'owner') return res.status(403).json({ error: 'owner_only' }); // админов назначает и снимает только владелец
  t.role = role; if (role !== 'user') t.applied = false;
  save(); res.json({ ok: true });
});
app.post('/api/admin/ban', isStaff, (req, res) => {
  const t = db.users[String(req.body?.email || '').toLowerCase()];
  if (!t || t.role === 'owner') return res.status(403).json({ error: 'forbidden' });
  if (t.role === 'admin' && req.user.role !== 'owner') return res.status(403).json({ error: 'owner_only' });
  t.banned = !!req.body.banned; save(); res.json({ ok: true });
});

app.listen(PORT, () => console.log(`Сайт запущен: http://localhost:${PORT}`));
