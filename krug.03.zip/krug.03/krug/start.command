#!/bin/bash
cd "$(dirname "$0")"
command -v node >/dev/null || { echo "Сначала установите Node.js с https://nodejs.org"; read -p "Enter..."; exit 1; }
[ -d node_modules ] || npm install
node setup.js
